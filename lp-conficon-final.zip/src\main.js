const problems = [
  {
    icon: "cash",
    title: "Drenagem de Caixa",
    text: "Impostos pagos a maior por falta de planejamento adequado reduzem drasticamente sua margem de lucro.",
  },
  {
    icon: "risk",
    title: "Insegurança Jurídica",
    text: "Riscos fiscais ocultos que podem comprometer severamente o futuro do seu patrimônio pessoal e negócio.",
  },
  {
    icon: "clock",
    title: "Lentidão Operacional",
    text: "Excesso de burocracia que impede o crescimento acelerado e a tomada de decisão estratégica em tempo real.",
  },
];

const services = [
  {
    title: "Gestão Fiscal e DP",
    text: "Conformidade absoluta com tecnologia de ponta e precisão joinvilense.",
  },
  {
    title: "BPO Financeiro",
    text: "Terceirização inteligente do financeiro para você focar no core business.",
  },
  {
    title: "Auditoria Digital",
    text: "Cruzamento de dados para prevenção de autuações e erros de apuração.",
  },
];

const proofs = [
  {
    index: "A",
    title: "Atendimento de Elite",
    text: "Consultores dedicados que conhecem profundamente as particularidades do seu setor.",
  },
  {
    index: "B",
    title: "Compliance Rigoroso",
    text: "Proteção total contra riscos fiscais através de processos de auditoria interna contínua.",
  },
  {
    index: "C",
    title: "Tecnologia Embarcada",
    text: "Dashboards inteligentes com seus indicadores financeiros atualizados em tempo real.",
  },
];

const navItems = ["Serviços", "Diferenciais", "Consultoria", "Sobre Nós"];
const companies = ["JOINVILLE TECH", "INDUSTRIA SC", "GLOBAL TRADE", "SERVICES PRO"];

function icon(name) {
  const paths = {
    cash: '<path d="M4 8.5h16v7H4z"/><path d="M7 12h.01M17 12h.01M10 12a2 2 0 1 0 4 0 2 2 0 0 0-4 0z"/>',
    risk: '<path d="m12 3 9 16H3L12 3z"/><path d="M12 9v4M12 16h.01"/>',
    clock: '<circle cx="12" cy="12" r="8"/><path d="M12 8v5l3 2"/>',
    arrow: '<path d="M5 12h14M13 6l6 6-6 6"/>',
    briefcase: '<path d="M9 7V5h6v2"/><rect x="4" y="7" width="16" height="11" rx="1"/><path d="M4 12h16"/>',
    shield: '<path d="M12 3 5 6v5c0 4 3 7 7 9 4-2 7-5 7-9V6l-7-3z"/>',
    chart: '<path d="M4 19V5M4 19h16M8 15v-4M12 15V8M16 15v-7"/>',
  };
  return `<svg class="icon" viewBox="0 0 24 24" aria-hidden="true">${paths[name] || paths.arrow}</svg>`;
}

function Logo() {
  return `
    <a class="logo" href="#" aria-label="Conficon">
      <span>CONFICON</span>
      <small>CONTABILIDADE ESTRATEGICA</small>
    </a>
  `;
}

function Nav() {
  return `
    <header class="topbar">
      <div class="container topbar__inner">
        ${Logo()}
        <button class="menu-toggle" type="button" aria-expanded="false" aria-controls="primary-menu">
          <span></span>
          <span></span>
          <span></span>
          <span class="sr-only">Abrir menu</span>
        </button>
        <nav class="nav" id="primary-menu" aria-label="Principal">
          ${navItems.map((item, i) => `<a class="${i === 0 ? "is-active" : ""}" href="#${item.toLowerCase().replace(" ", "-")}">${item}</a>`).join("")}
          <a class="button button--nav" href="#contato">Falar com Consultor</a>
        </nav>
      </div>
    </header>
  `;
}

function Hero() {
  return `
    <section class="hero">
      <div class="container hero__grid">
        <div class="hero__content">
          <p class="eyebrow">CONTABILIDADE ESTRATÉGICA</p>
          <h1>Pague apenas o necessário e transforme sua contabilidade em uma ferramenta de lucro.</h1>
          <p class="lead">Especialistas em planejamento tributário e contabilidade estratégica em Joinville/SC. Aliamos tecnologia e visão consultiva para o seu crescimento.</p>
          <div class="actions">
            <a class="button button--primary" href="#contato">Falar com um Consultor Estratégico</a>
            <a class="button button--outline" href="#metodos">Conhecer Nossos Métodos</a>
          </div>
        </div>
        <div class="hero__media" aria-hidden="true">
          <img src="./assets/hero-photo.png" alt="" />
        </div>
      </div>
    </section>
  `;
}

function ProblemSection() {
  return `
    <section class="section section--dark">
      <div class="container section__stack reveal">
        <h2 class="section__title section__title--center">Sua empresa está perdendo dinheiro para a burocracia e impostos indevidos?</h2>
        <div class="problem-grid">
          ${problems
            .map(
              (item) => `
                <article class="problem-card">
                  ${icon(item.icon)}
                  <h3>${item.title}</h3>
                  <p>${item.text}</p>
                </article>
              `,
            )
            .join("")}
        </div>
      </div>
    </section>
  `;
}

function ServicesSection() {
  return `
    <section class="section section--soft" id="serviços">
      <div class="container section__stack section__stack--wide reveal">
        <div class="section-head">
          <div>
            <p class="eyebrow">NOSSA EXPERTISE</p>
            <h2>Soluções modulares para uma gestão tributária de alta performance.</h2>
          </div>
          <a class="text-link" href="#servicos">Ver todos os serviços ${icon("arrow")}</a>
        </div>

        <div class="services-grid">
          <article class="service-card service-card--main">
            <div>
              <span class="service-icon">${icon("chart")}</span>
              <h3>Planejamento Tributário</h3>
              <p>Análise profunda e legal para otimização da carga tributária, garantindo eficiência financeira máxima para seu modelo de negócio específico.</p>
            </div>
            <footer>
              <span>CONSULTORIA PREMIUM</span>
              ${icon("arrow")}
            </footer>
          </article>

          <div class="service-side">
            <article class="service-card service-card--muted">
              <div>
                <span class="mini-icon">${icon("briefcase")}</span>
                <h3>Reforma Tributária</h3>
                <p>Preparamos sua empresa para as mudanças legislativas iminentes, mitigando riscos.</p>
              </div>
              ${icon("arrow")}
            </article>
            <article class="service-card service-card--dark">
              <div>
                <span class="mini-icon">${icon("shield")}</span>
                <h3>Gestão Societária</h3>
                <p>Estruturação de holdings e proteção patrimonial estratégica.</p>
              </div>
              ${icon("arrow")}
            </article>
          </div>

          ${services
            .map(
              (service) => `
                <article class="service-card service-card--small">
                  <h3>${service.title}</h3>
                  <p>${service.text}</p>
                </article>
              `,
            )
            .join("")}
        </div>
      </div>
    </section>
  `;
}

function ProofSection() {
  return `
    <section class="section section--white" id="diferenciais">
      <div class="container proof-grid reveal">
        <div class="proof-copy">
          <p class="eyebrow">POR QUE CONFICON</p>
          <h2>Segurança para o seu patrimônio, agilidade para o seu negócio.</h2>
          <div class="proof-list">
            ${proofs
              .map(
                (item) => `
                  <article class="proof-item">
                    <span>${item.index}</span>
                    <div>
                      <h3>${item.title}</h3>
                      <p>${item.text}</p>
                    </div>
                  </article>
                `,
              )
              .join("")}
          </div>
        </div>
        <div class="proof-media">
          <img src="./assets/meeting-photo.png" alt="Reunião consultiva da Conficon" />
          <div class="metric">
            <strong>15+</strong>
            <span>15+ ANOS DE EXPERIÊNCIA EM JOINVILLE</span>
          </div>
        </div>
      </div>
    </section>
  `;
}

function AboutSection() {
  return `
    <section class="section section--soft" id="sobre-nós">
      <div class="container about reveal">
        <p class="eyebrow">SOBRE NÓS</p>
        <h2>Nascida em Joinville para transformar o mercado contábil.</h2>
        <p>A Conficon Contabilidade não é apenas um escritório de registros; somos parceiros estratégicos de negócios que buscam solidez e expansão sustentável. Unimos a tradição de confiança joinvilense com inovação para entregar resultados financeiros mensuráveis.</p>
        <div class="company-strip">
          ${companies.map((company) => `<span>${company}</span>`).join("")}
        </div>
      </div>
    </section>
  `;
}

function FinalCta() {
  return `
    <section class="final-wrap" id="contato">
      <div class="container">
        <div class="final-cta reveal">
          <h2>Pronto para elevar o nível da sua gestão tributária?</h2>
          <p>Agende uma conversa diagnóstica gratuita com nossos consultores seniores e descubra o potencial de economia oculto na sua operação.</p>
          <a class="button button--gold" href="mailto:contato@conficon.com.br">Falar com um Especialista ${icon("arrow")}</a>
        </div>
      </div>
    </section>
  `;
}

function Footer() {
  return `
    <footer class="footer">
      <div class="container">
        <div class="footer__top">
          <div class="footer__brand">
            ${Logo()}
            <p>Contabilidade estratégica e consultoria tributária em Joinville/SC. Transformando burocracia em inteligência financeira para o seu negócio.</p>
            <div class="socials"><a href="#">in</a><a href="#">ig</a><a href="#">yt</a></div>
          </div>
          <div class="footer__col">
            <h4>EMPRESA</h4>
            <a href="#">Sobre Nós</a><a href="#">Carreiras</a><a href="#">Blog</a><a href="#">Contato</a>
          </div>
          <div class="footer__col">
            <h4>SERVIÇOS</h4>
            <a href="#">Planejamento</a><a href="#">Gestão Fiscal</a><a href="#">BPO Financeiro</a><a href="#">Societário</a>
          </div>
          <form class="newsletter">
            <h4>NEWSLETTER</h4>
            <p>Receba insights mensais sobre economia e tributação.</p>
            <label>
              <span class="sr-only">Seu e-mail</span>
              <input type="email" placeholder="Seu e-mail" />
              <button type="submit">OK</button>
            </label>
          </form>
        </div>
        <div class="footer__bottom">
          <p>© 2024 Conficon Contabilidade Estratégica. Todos os direitos reservados.</p>
          <nav><a href="#">Privacidade</a><a href="#">Termos</a><a href="#">Compliance</a></nav>
        </div>
      </div>
    </footer>
  `;
}

document.querySelector("#app").innerHTML = `
  ${Nav()}
  <main>
    ${Hero()}
    ${ProblemSection()}
    ${ServicesSection()}
    ${ProofSection()}
    ${AboutSection()}
    ${FinalCta()}
  </main>
  ${Footer()}
`;

const toggle = document.querySelector(".menu-toggle");
const menu = document.querySelector("#primary-menu");

toggle?.addEventListener("click", () => {
  const isOpen = toggle.getAttribute("aria-expanded") === "true";
  toggle.setAttribute("aria-expanded", String(!isOpen));
  menu?.classList.toggle("is-open", !isOpen);
  document.body.classList.toggle("menu-open", !isOpen);
});

menu?.querySelectorAll("a").forEach((link) => {
  link.addEventListener("click", () => {
    toggle?.setAttribute("aria-expanded", "false");
    menu.classList.remove("is-open");
    document.body.classList.remove("menu-open");
  });
});

const reveals = document.querySelectorAll(".reveal");

if ("IntersectionObserver" in window) {
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.15, rootMargin: "0px 0px -60px 0px" },
  );

  reveals.forEach((el) => observer.observe(el));
} else {
  reveals.forEach((el) => el.classList.add("is-visible"));
}
